
# How to upload to GitHub (commands)

1. Create a new repository on GitHub (via website or `gh` CLI) named `EI-Coding-Exercises`.
2. From the extracted folder on your machine, run:

```bash
git init
git add .
git commit -m "Add EI Coding Exercises (Exercise 1 + Exercise 2)"
git branch -M main
# replace <YOUR-GIT-URL> with the repo URL you created, e.g. git@github.com:you/EI-Coding-Exercises.git
git remote add origin <YOUR-GIT-URL>
git push -u origin main
```

If you have `gh` (GitHub CLI) you can create and push in one step:

```bash
gh repo create your-username/EI-Coding-Exercises --public --source=. --remote=origin --push
```

After pushing, share the GitHub repo URL (the URL required by the assignment).
