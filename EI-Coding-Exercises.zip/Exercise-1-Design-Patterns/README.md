
# Exercise 1 — Design Patterns Demos (Java)

This folder contains console demos that illustrate 6 use-cases across three categories:

- Behavioral:
  - Observer (news publisher / subscribers)
  - Command (remote control + light commands)
- Creational:
  - Singleton (AppConfig singleton usage)
  - Factory (Notification factory producing Email/SMS notifications)
- Structural:
  - Adapter (media player adapter)
  - Composite (file-system composite with directories and files)

To compile and run the demos (Linux/macOS), from this folder:

```bash
# compile all java files to bin/
find src -name "*.java" > sources.txt
javac -d bin @sources.txt

# run demos
java -cp bin com.eicoding.exercise1.behavioral.observer.ObserverDemo
java -cp bin com.eicoding.exercise1.behavioral.command.CommandDemo
java -cp bin com.eicoding.exercise1.creational.singleton.SingletonDemo
java -cp bin com.eicoding.exercise1.creational.factory.FactoryDemo
java -cp bin com.eicoding.exercise1.structural.adapter.AdapterDemo
java -cp bin com.eicoding.exercise1.structural.composite.CompositeDemo
```

(If you're on Windows, compile with an IDE or adapt commands.)
