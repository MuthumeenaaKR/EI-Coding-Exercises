
package com.eicoding.exercise1.behavioral.observer;

public class ConsoleSubscriber implements Subscriber {
    private final String name;
    public ConsoleSubscriber(String name) {
        this.name = name;
    }

    @Override
    public void update(String news) {
        System.out.println("[Subscriber: " + name + "] Received -> " + news);
    }
}
