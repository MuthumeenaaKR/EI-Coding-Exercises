
package com.eicoding.exercise1.behavioral.observer;

import java.util.ArrayList;
import java.util.List;

public class Publisher {
    private final List<Subscriber> subscribers = new ArrayList<>();
    private String latestNews;

    public void subscribe(Subscriber s) {
        subscribers.add(s);
    }

    public void unsubscribe(Subscriber s) {
        subscribers.remove(s);
    }

    public void publish(String news) {
        this.latestNews = news;
        notifyAllSubscribers();
    }

    private void notifyAllSubscribers() {
        for (Subscriber s : subscribers) {
            s.update(latestNews);
        }
    }
}
