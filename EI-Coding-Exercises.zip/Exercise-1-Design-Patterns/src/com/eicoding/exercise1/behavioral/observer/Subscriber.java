
package com.eicoding.exercise1.behavioral.observer;

public interface Subscriber {
    void update(String news);
}
