
package com.eicoding.exercise1.behavioral.observer;

public class ObserverDemo {
    public static void main(String[] args) {
        Publisher publisher = new Publisher();
        Subscriber alice = new ConsoleSubscriber("Alice");
        Subscriber bob = new ConsoleSubscriber("Bob");
        publisher.subscribe(alice);
        publisher.subscribe(bob);

        System.out.println("--- Observer Demo: News Publisher ---");
        publisher.publish("Mission update: Launch scheduled at 09:00 UTC.");
        System.out.println();

        publisher.unsubscribe(bob);
        System.out.println("Bob unsubscribed.");
        publisher.publish("Alert: Incoming solar flare detected. Take shelter.");
    }
}
