
package com.eicoding.exercise1.behavioral.command;

public interface Command {
    void execute();
}
