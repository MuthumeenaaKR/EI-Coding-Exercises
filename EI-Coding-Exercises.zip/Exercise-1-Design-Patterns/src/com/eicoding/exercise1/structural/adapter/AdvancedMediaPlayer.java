
package com.eicoding.exercise1.structural.adapter;

public interface AdvancedMediaPlayer {
    void playMp3(String fileName);
    void playMp4(String fileName);
}
