
package com.eicoding.exercise1.structural.adapter;

public interface MediaPlayer {
    void play(String audioType, String fileName);
}
