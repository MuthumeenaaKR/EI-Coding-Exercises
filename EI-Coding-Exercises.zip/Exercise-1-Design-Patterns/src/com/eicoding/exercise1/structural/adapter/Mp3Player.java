
package com.eicoding.exercise1.structural.adapter;

public class Mp3Player implements AdvancedMediaPlayer {
    @Override
    public void playMp3(String fileName) {
        System.out.println("Playing mp3 file: " + fileName);
    }
    @Override
    public void playMp4(String fileName) {
        // do nothing
    }
}
