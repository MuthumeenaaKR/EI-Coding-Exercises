
package com.eicoding.exercise1.structural.adapter;

public class MediaAdapter implements MediaPlayer {

    private final AdvancedMediaPlayer advancedMusicPlayer;

    public MediaAdapter(String audioType) {
        if ("mp3".equalsIgnoreCase(audioType)) {
            advancedMusicPlayer = new Mp3Player();
        } else if ("mp4".equalsIgnoreCase(audioType)) {
            advancedMusicPlayer = new Mp4Player();
        } else {
            advancedMusicPlayer = null;
        }
    }

    @Override
    public void play(String audioType, String fileName) {
        if (advancedMusicPlayer == null) {
            System.out.println("Unsupported media type: " + audioType);
            return;
        }
        if ("mp3".equalsIgnoreCase(audioType)) {
            advancedMusicPlayer.playMp3(fileName);
        } else if ("mp4".equalsIgnoreCase(audioType)) {
            advancedMusicPlayer.playMp4(fileName);
        }
    }
}
