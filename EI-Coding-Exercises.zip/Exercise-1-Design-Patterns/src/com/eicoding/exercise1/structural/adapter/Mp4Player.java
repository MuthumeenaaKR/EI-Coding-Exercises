
package com.eicoding.exercise1.structural.adapter;

public class Mp4Player implements AdvancedMediaPlayer {
    @Override
    public void playMp3(String fileName) {
        // do nothing
    }
    @Override
    public void playMp4(String fileName) {
        System.out.println("Playing mp4 file: " + fileName);
    }
}
