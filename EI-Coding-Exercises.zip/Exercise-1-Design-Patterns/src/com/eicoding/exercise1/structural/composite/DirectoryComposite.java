
package com.eicoding.exercise1.structural.composite;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class DirectoryComposite extends FileSystemComponent {
    private final List<FileSystemComponent> children = new ArrayList<>();

    public DirectoryComposite(String name) {
        super(name);
    }

    @Override
    public int getSize() {
        int sum = 0;
        for (FileSystemComponent c : children) sum += c.getSize();
        return sum;
    }

    @Override
    public void print(String indent) {
        System.out.println(indent + "+ " + name + " (dir)");
        for (FileSystemComponent c : children) c.print(indent + "  ");
    }

    @Override
    public void add(FileSystemComponent c) {
        children.add(c);
    }

    @Override
    public Optional<FileSystemComponent> find(String name) {
        for (FileSystemComponent c : children) {
            if (c.name.equals(name)) return Optional.of(c);
            Optional<FileSystemComponent> found = c.find(name);
            if (found.isPresent()) return found;
        }
        return Optional.empty();
    }
}
