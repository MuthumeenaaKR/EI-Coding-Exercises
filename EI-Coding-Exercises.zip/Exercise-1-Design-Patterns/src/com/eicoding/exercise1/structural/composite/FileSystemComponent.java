
package com.eicoding.exercise1.structural.composite;

import java.util.Optional;

public abstract class FileSystemComponent {
    protected final String name;

    protected FileSystemComponent(String name) {
        this.name = name;
    }

    public abstract int getSize();
    public abstract void print(String indent);
    // default implementations for composite operations
    public void add(FileSystemComponent c) {
        throw new UnsupportedOperationException("Not supported");
    }
    public Optional<FileSystemComponent> find(String name) {
        return Optional.empty();
    }
}
