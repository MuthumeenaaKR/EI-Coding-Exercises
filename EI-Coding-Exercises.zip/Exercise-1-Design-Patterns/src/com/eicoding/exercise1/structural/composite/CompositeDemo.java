
package com.eicoding.exercise1.structural.composite;

public class CompositeDemo {
    public static void main(String[] args) {
        System.out.println("--- Composite Demo: File System ---");
        DirectoryComposite root = new DirectoryComposite("root");
        DirectoryComposite home = new DirectoryComposite("home");
        DirectoryComposite docs = new DirectoryComposite("docs");
        FileLeaf file1 = new FileLeaf("notes.txt", 12);
        FileLeaf file2 = new FileLeaf("photo.jpg", 2048);

        docs.add(file1);
        home.add(docs);
        home.add(file2);
        root.add(home);

        root.print("");
        System.out.println("Total size: " + root.getSize() + " KB");
    }
}
