
package com.eicoding.exercise1.structural.composite;

public class FileLeaf extends FileSystemComponent {
    private final int size;

    public FileLeaf(String name, int size) {
        super(name);
        this.size = size;
    }

    @Override
    public int getSize() {
        return size;
    }

    @Override
    public void print(String indent) {
        System.out.println(indent + "- " + name + " (" + size + " KB)");
    }
}
