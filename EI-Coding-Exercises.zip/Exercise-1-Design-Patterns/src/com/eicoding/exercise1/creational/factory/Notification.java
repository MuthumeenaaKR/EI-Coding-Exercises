
package com.eicoding.exercise1.creational.factory;

public interface Notification {
    void notifyUser(String message);
}
