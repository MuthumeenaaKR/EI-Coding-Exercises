
package com.eicoding.exercise1.creational.factory;

public class SMSNotification implements Notification {
    private final String phoneNumber;
    public SMSNotification(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }
    @Override
    public void notifyUser(String message) {
        System.out.println("Sending SMS to " + phoneNumber + ": " + message);
    }
}
