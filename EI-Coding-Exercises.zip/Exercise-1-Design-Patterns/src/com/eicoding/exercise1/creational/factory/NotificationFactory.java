
package com.eicoding.exercise1.creational.factory;

public class NotificationFactory {
    public enum Type { EMAIL, SMS }

    public static Notification createNotification(Type t, String target) {
        switch (t) {
            case EMAIL:
                return new EmailNotification(target);
            case SMS:
                return new SMSNotification(target);
            default:
                throw new IllegalArgumentException("Unsupported notification type");
        }
    }
}
