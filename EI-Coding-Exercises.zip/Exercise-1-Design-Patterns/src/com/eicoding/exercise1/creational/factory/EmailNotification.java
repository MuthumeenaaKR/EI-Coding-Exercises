
package com.eicoding.exercise1.creational.factory;

public class EmailNotification implements Notification {
    private final String emailAddress;
    public EmailNotification(String emailAddress) {
        this.emailAddress = emailAddress;
    }
    @Override
    public void notifyUser(String message) {
        System.out.println("Sending EMAIL to " + emailAddress + ": " + message);
    }
}
