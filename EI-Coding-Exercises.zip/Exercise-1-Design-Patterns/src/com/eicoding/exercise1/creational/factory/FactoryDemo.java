
package com.eicoding.exercise1.creational.factory;

public class FactoryDemo {
    public static void main(String[] args) {
        System.out.println("--- Factory Demo: Notifications ---");
        Notification welcomeEmail = NotificationFactory.createNotification(NotificationFactory.Type.EMAIL, "astronaut@space.org");
        Notification alertSms = NotificationFactory.createNotification(NotificationFactory.Type.SMS, "+1234567890");

        welcomeEmail.notifyUser("Welcome onboard! Please review your schedule.");
        alertSms.notifyUser("URGENT: Unplanned maintenance on Module 3.");
    }
}
