
# EI Coding Exercises (Java)

This repository contains two completed exercises prepared for the EI coding assessment:

1. **Exercise 1 – Design Patterns demos**  
   Short console demos (six use-cases) covering Behavioral, Creational and Structural patterns.

2. **Exercise 2 – Astronaut Daily Schedule Organizer**  
   A console-based mini-project demonstrating SOLID, OOP, and design patterns (Singleton, Factory, Observer).

> I cannot create a GitHub repository or push code to GitHub from here.  
> However this package is ready to be uploaded to GitHub: unzip, inspect, then `git init` / `git add` / `git commit` / `git remote add origin ...` and `git push`.  
> Detailed push instructions are included in the `UPLOAD_TO_GITHUB.md` file.

