
package com.eicoding.exercise2.scheduler;

public enum AppState {
    RUNNING,
    EXIT
}
