
package com.eicoding.exercise2.scheduler;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

public class TaskFactory {
    private static final DateTimeFormatter TF = DateTimeFormatter.ofPattern("HH:mm");

    public static Task createTask(String description, String startTime, String endTime, String priority) throws IllegalArgumentException {
        try {
            LocalTime s = LocalTime.parse(startTime, TF);
            LocalTime e = LocalTime.parse(endTime, TF);
            return new Task(description, s, e, priority);
        } catch (DateTimeParseException ex) {
            throw new IllegalArgumentException("Invalid time format. Expected HH:mm", ex);
        }
    }
}
