
package com.eicoding.exercise2.scheduler;

public interface Observer {
    void notify(String message);
}
